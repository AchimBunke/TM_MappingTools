window.scrollToBottom = (el) => {
    if (el) el.scrollTop = el.scrollHeight;
};

window.isScrolledToBottom = (el) => {
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight < 6;
};

window.syncArticlePadding = (panelEl) => {
    const article = document.querySelector('main > article.content');
    if (article && panelEl) article.style.paddingBottom = panelEl.offsetHeight + 'px';
    else if (article) article.style.paddingBottom = '';
};

window.initOutputPanelResize = (panelEl, handleEl) => {
    if (!panelEl || !handleEl) return;
    const syncPadding = () => {
        const article = document.querySelector('main > article.content');
        if (article) article.style.paddingBottom = panelEl.offsetHeight + 'px';
    };
    syncPadding();
    handleEl.addEventListener('mousedown', (e) => {
        const startY = e.clientY;
        const startHeight = panelEl.offsetHeight;
        e.preventDefault();
        document.body.style.userSelect = 'none';
        const onMove = (mv) => {
            const newH = Math.max(60, Math.min(window.innerHeight * 0.7, startHeight + (startY - mv.clientY)));
            panelEl.style.height = newH + 'px';
            syncPadding();
        };
        const onUp = () => {
            document.body.style.userSelect = '';
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
};

window.downloadFileFromStream = async (fileName, streamRef) => {
    const arrayBuffer = await streamRef.arrayBuffer();
    const blob = new Blob([arrayBuffer]);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
}

window.initializeFileDropZone = async (dropZoneElement, inputFile) => {
    let dragDepth = 0;

    function onDragEnter(e) {
        e.preventDefault();
        if (++dragDepth === 1) dropZoneElement.classList.add("hover");
    }

    function onDragOver(e) {
        e.preventDefault();
    }

    function onDragLeave(e) {
        e.preventDefault();
        if (--dragDepth <= 0) { dragDepth = 0; dropZoneElement.classList.remove("hover"); }
    }

    // Handle the paste and drop events
    function onDrop(e) {
        e.preventDefault();
        dragDepth = 0;
        dropZoneElement.classList.remove("hover");

        // Set the files property of the input element and raise the change event
        inputFile.files = e.dataTransfer.files;
        const event = new Event('change', { bubbles: true });
        inputFile.dispatchEvent(event);
    }

    function onDragEnd() {
        dragDepth = 0;
        dropZoneElement.classList.remove("hover");
    }

    // Catches the case where the user drags out of the browser window entirely
    function onDocumentDragLeave(e) {
        if (e.relatedTarget === null) {
            dragDepth = 0;
            dropZoneElement.classList.remove("hover");
        }
    }

    function onPaste(e) {
        // Set the files property of the input element and raise the change event
        inputFile.files = e.clipboardData.files;
        const event = new Event('change', { bubbles: true });
        inputFile.dispatchEvent(event);
    }

    // Register all events
    dropZoneElement.addEventListener("dragenter", onDragEnter);
    dropZoneElement.addEventListener("dragover", onDragOver);
    dropZoneElement.addEventListener("dragleave", onDragLeave);
    dropZoneElement.addEventListener("drop", onDrop);
    dropZoneElement.addEventListener('paste', onPaste);
    dropZoneElement.addEventListener("dragend", onDragEnd);
    document.addEventListener("dragleave", onDocumentDragLeave);

    // The returned object allows to unregister the events when the Blazor component is destroyed
    return {
        dispose: () => {
            dropZoneElement.removeEventListener('dragenter', onDragEnter);
            dropZoneElement.removeEventListener('dragover', onDragOver);
            dropZoneElement.removeEventListener('dragleave', onDragLeave);
            dropZoneElement.removeEventListener("drop", onDrop);
            dropZoneElement.removeEventListener('paste', onPaste);
            dropZoneElement.removeEventListener("dragend", onDragEnd);
            document.removeEventListener("dragleave", onDocumentDragLeave);
        }
    }
}


window.getTheme = () => localStorage.getItem('tm-theme') || 'dark';

window.applyTheme = (theme) => {
    if (theme === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    else document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('tm-theme', theme);
};

window.toggleTheme = () => {
    var current = localStorage.getItem('tm-theme') || 'dark';
    var next = current === 'dark' ? 'light' : 'dark';
    window.applyTheme(next);
    return next;
};
